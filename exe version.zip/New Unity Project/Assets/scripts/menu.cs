﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class menu : MonoBehaviour {

	Vector3 onScreen;
	Vector3 offScreen;

	GameObject winScreen;
	GameObject mMenu;
	GameObject pauseMenu;
	GameObject gameOver;
	public bool pauseThing = false;

	// Use this for initialization
	void Start () {
		
		winScreen = GameObject.Find ("Winner");
		mMenu = GameObject.Find ("menu");
		pauseMenu = GameObject.Find ("pause");
		gameOver = GameObject.Find ("gameOver");

		onScreen.x = Screen.width / 2;
		onScreen.y = Screen.height / 2;
		offScreen.x = Screen.width * 5;
		offScreen.y = Screen.height * 5;
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKey("escape")){
			pauseThing = true;
		}

		if (pauseThing == true){
			pauseGame ();
		}
	}

	public void pauseGame(){
		pauseMenu.transform.position = onScreen;
	}

	public void resumeGame(){
		pauseMenu.transform.position = offScreen;
		pauseThing = false;
	}

	public void goToMenu(){
		SceneManager.LoadScene ("menu");
	}

	public void playGame(){
		SceneManager.LoadScene ("gameplay");
	}

	public void leaveGame(){
		Application.Quit ();
	}

	public void winGame(){
		winScreen.transform.position = onScreen;
	}

}
