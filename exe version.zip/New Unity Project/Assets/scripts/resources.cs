﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class resources : MonoBehaviour {
	GameObject menuThing;
	GameObject dayTracker;
	string days;

	public float roomCap = 1;
	GameObject timey;
	GameObject score;
	GameObject text;

	public float treated;
	public float notTreated;
	public float totalTreated = 0;

	GameObject Money;
	public string moneyString;
	public float currentMoney = 10f;
	public float moneyDiff; 							//amount of money gained/lost at end of the day
	public float moneyOrigin;							 //money at start of the day
	public string plusOrMinus;

	public float payment;

	GameObject Staff;
	public string staffString;
	public float currentStaff = 3f;

	GameObject Patient;
	public string patientString;
	public float currentPatient = 15f; 					 // tracks current number of patients
	public float patOrigin = 15f; 						 //number of patients the previos day
	public float patientTotal; 								 //total number of patients for the new day

	public float DayNum = 1f;
	public float upKeep;

	public string poor;

	void Start () {
		
		menuThing = GameObject.Find ("Main Camera");
		dayTracker = GameObject.Find ("days");
		timey = GameObject.Find ("pointer");
		text = GameObject.Find ("textGirl");
		Money = GameObject.Find ("moneyText");
		Staff = GameObject.Find ("staffText");
		Patient = GameObject.Find ("patientText");

		poor = "you don't have enough money";
			
		score = GameObject.Find ("scoreBoard");
	}


	public void Update () {
		moneyString = ("$ " + (currentMoney.ToString ()));
		Money.GetComponent<Text>().text = moneyString;

		staffString = (currentStaff.ToString () + " Staff");
		Staff.GetComponent<Text> ().text = staffString;

		patientString = (currentPatient.ToString () + " Patients");
		Patient.GetComponent<Text> ().text = patientString;
	}

	public void DayNumber (){															//keep track of day number
		DayNum ++;
		days = DayNum.ToString();
		//win condtion
		dayTracker.GetComponent<Text> ().text = days;
		if((DayNum == 10f) && (roomCap > 5)){
			menuThing.GetComponent<menu> ().winGame ();
		}
	}

	public void newDay (){ 																	//new day patient number

		totalTreated = 0;
		notTreated = 0f;
		//new number of patients
		int rand = Random.Range(5, 15);		
		gameOver ();

		float rand1 = (float)rand;
		patientTotal = (50f+rand1) + (roomCap+1) * 10f;
		//patientTotal = patOrigin + (DayNum * rand1);
		patOrigin = patientTotal;
		currentPatient = patientTotal;

		//set money origin
		moneyOrigin = currentMoney;
		Debug.Log ("payment is  "+ payment);
	}


	//pay upkeep equal to 10% of current money (plus 1% per room)
	public void payUpkeep(){
		double percent = (currentMoney / 100) * 10;   //10 % of current money
		double roomPercent = (currentMoney / 100) * roomCap; //1 percent for every room unlocked
		percent =+ roomPercent;
		percent = System.Math.Round (percent, 0);
		upKeep = (float)percent;
		currentMoney = currentMoney - upKeep;
	}

	//pay staff and pay for untreated patients
	public void PayStaff(){
		payment = currentStaff * 100f;
		currentMoney = currentMoney - payment;	

		float losePay = notTreated * 8f;
		currentMoney = currentMoney - losePay;
	}



	// calculations to treat patients
	public void treatPat(){												
		if ((currentStaff * 5f)  > currentPatient) {
			treated = currentPatient;
			currentPatient = 0;
		} else {
			treated = currentStaff * 5f;
			notTreated = currentPatient - treated;
		}
		currentPatient = notTreated;

		float payment1 = treated * 15f;
		currentMoney = currentMoney + payment1;
		totalTreated += treated;
	}

	public void moneyDifference(){
		moneyDiff = currentMoney - moneyOrigin;
		if (moneyDiff > 0f) {
			plusOrMinus = "+ ";
		} else {
			plusOrMinus = " ";
		}
	}

	public void scoreBorad(){
		moneyDifference ();
		score.GetComponent<ScoreBoard> ().getStats(currentStaff, patOrigin, totalTreated, moneyDiff, plusOrMinus);
		
	}

	public void newRoom(float newMoney){
		roomCap++;
		currentMoney = currentMoney - newMoney;
	}

	public bool countMoney(float newMoney){
		bool check;
		if (currentMoney < newMoney) {
			check = false;
		} else {
			check = true;
		}

		return check;
	}

	public void tooPoor(){
		text.GetComponent<Text> ().text = poor;
		Debug.Log (" pooorrr af");
	}

	public void AddStaff (float newMoney){
		if (currentMoney < newMoney) {
			tooPoor ();
		} else {
			currentMoney = currentMoney - newMoney;
			currentStaff++;
			timey.GetComponent<TimeChanger> ().change ();
		}
	}

	public void TakeStaff(float newStaff){
		currentStaff = currentStaff - newStaff;
		if (currentStaff < 0){
			currentStaff = 0;
		}
	}

	public void gameOver(){
		if (currentMoney < 0){
			Debug.Log (" you lose");
		}

	}

}
