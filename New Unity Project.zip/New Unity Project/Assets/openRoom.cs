﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class openRoom : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void yourmum(){
		//called from rooms.cs switch case
		//make button and text appear to buy room

	}

	public void buyRoom(){
		//activate all room buffs
		//set some random bool value to false so u cant buy room twice

	}
}
