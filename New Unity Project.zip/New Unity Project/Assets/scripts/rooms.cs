﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class rooms : MonoBehaviour {

	GameObject resource;

	GameObject room1; 
	GameObject room2; 
	GameObject room3; 
	GameObject room4; 
	GameObject room5; 
	GameObject room6; 
	GameObject room7; 
	GameObject room8; 
	GameObject room9; 
	GameObject room10; 



	public string notBought;
	public string bought;

	GameObject info;

	void Start () {
		resource = GameObject.Find ("Main Camera");
		info = GameObject.Find("item_Info");

		room1 = GameObject.Find ("room1");
		room2 = GameObject.Find ("room2");
		room3 = GameObject.Find ("room3");
		room4 = GameObject.Find ("room4");
		room5 = GameObject.Find ("room5");
		room6 = GameObject.Find ("room6");
		room7 = GameObject.Find ("room7");
		room8 = GameObject.Find ("room8");
		room9 = GameObject.Find ("room9");
		room10 = GameObject.Find ("room10");


		bought = "you have already bought this room";

		notBought = "Unlocking this room will make your hospital able to" +
			" hold an additional 10 patients per day. Patients, when treated, " +
			" will pay you $10.";
	}


	void Update () {
		Ray ray = Camera.main.ScreenPointToRay (Input.mousePosition);
		RaycastHit hit;

		if (Input.GetMouseButtonDown (0)) {							//this block of code can be replaced by an external script that causes the time of day to shift
			if (Physics.Raycast (ray, out hit)) {					//
				switch (hit.collider.tag) {
				case "room1":
					if (room1.GetComponent<Collider> ()) {
						//room is not bought
						openInfo ();
					} 
					break;
				case "room2":
					if (room2.GetComponent<Collider> ()) {
						room2.GetComponent<openRoom> ().yourmum ();  ///this will open a window with a buy room button
						openInfo ();
					} 
					break;
				case "room3":
					if (room3.GetComponent<Collider> ()) {
						openInfo ();
					} 
					break;
				case "room4":
					if (room3.GetComponent<Collider> ()) {
						openInfo ();
					} 
					break;
				case "room5":
					if (room3.GetComponent<Collider> ()) {
						openInfo ();
					} 
					break;
				case "room6":
					if (room3.GetComponent<Collider> ()) {
						openInfo ();
					} 
					break;
				case "room7":
					if (room3.GetComponent<Collider> ()) {
						openInfo ();
					} 
					break;
				case "room8":
					if (room3.GetComponent<Collider> ()) {
						openInfo ();
					} 
					break;
				case "room9":
					if (room3.GetComponent<Collider> ()) {
						openInfo ();
					} 
					break;
				case "room10":
					if (room3.GetComponent<Collider> ()) {
						openInfo ();
					} 
					break;
				default: 
					break;
				}
			
			}
		}
	}

	public void openInfoBought(){
		GetComponent<Text>().text = bought; 
		info.GetComponent<Text> ().text = GetComponent<Text>().text;
	
	}

	public void openInfo(){
		GetComponent<Text>().text = notBought; 
		info.GetComponent<Text> ().text = GetComponent<Text>().text;

	}
		

}
